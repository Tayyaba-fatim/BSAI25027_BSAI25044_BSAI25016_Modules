﻿using UnityEngine;

public class GlassSlab : MonoBehaviour
{
    [Header("Glass Properties")]
    public float refractiveIndex = 1.5f;
    public float rayWidth = 0.05f;
    public float rayLength = 10f;

    private LineRenderer refractedRay;
    private LineRenderer emergentRay;

    void Start()
    {
        refractedRay = CreateRay("RefractedRay", Color.cyan);
        emergentRay = CreateRay("EmergentRay", Color.green);

        //  Both hidden at start
        HideRays();
    }

    LineRenderer CreateRay(string name, Color color)
    {
        GameObject obj = new GameObject(name);
        obj.transform.parent = transform;
        LineRenderer lr = obj.AddComponent<LineRenderer>();
        lr.startWidth = rayWidth;
        lr.endWidth = rayWidth;
        Material mat = new Material(Shader.Find("Unlit/Color"));
        mat.color = color;
        lr.material = mat;
        lr.startColor = color;
        lr.endColor = color;
        lr.positionCount = 2;
        lr.useWorldSpace = true;
        lr.enabled = false;
        return lr;
    }

    public void ReceiveRay(Vector3 startPoint, Vector3 direction,
                           float angleOfIncidence)
    {
        // Show refracted rays when hit
        refractedRay.enabled = true;
        emergentRay.enabled = true;

        Vector3 hitPoint = transform.position;

        // Snell's Law
        float n1 = 1.0f;
        float n2 = refractiveIndex;
        float sinTheta1 = Mathf.Sin(angleOfIncidence * Mathf.Deg2Rad);
        float sinTheta2 = Mathf.Clamp((n1 / n2) * sinTheta1, -1f, 1f);
        float theta2 = Mathf.Asin(sinTheta2) * Mathf.Rad2Deg;

        //  Cyan ray inside glass
        Vector3 refractDir = Quaternion.Euler(0, 0, theta2) * direction;
        Vector3 exitPoint = hitPoint + refractDir * 1f;
        refractedRay.SetPosition(0, hitPoint);
        refractedRay.SetPosition(1, exitPoint);

        //  Green ray coming out (parallel to incident)
        Vector3 emergentEnd = exitPoint + direction * rayLength;
        emergentRay.SetPosition(0, exitPoint);
        emergentRay.SetPosition(1, emergentEnd);

        Debug.Log($"Angle of Incidence:  {angleOfIncidence:F1}°");
        Debug.Log($"Angle of Refraction: {theta2:F1}°");
    }

    public void HideRays()
    {
        if (refractedRay != null) refractedRay.enabled = false;
        if (emergentRay != null) emergentRay.enabled = false;
    }

    void Update()
    {
        //  LEFT/RIGHT arrows rotate slab
        var kb = UnityEngine.InputSystem.Keyboard.current;
        if (kb.leftArrowKey.isPressed)
            transform.Rotate(0, 0, 1f);
        if (kb.rightArrowKey.isPressed)
            transform.Rotate(0, 0, -1f);
    }
}